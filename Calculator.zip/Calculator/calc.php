<!DOCTYPE html>
<html>
<head>
<title>Calculator</title>
<link rel="stylesheet" type="text/css" href="style.css">
<script src="functions.js"></script>
</head>

<body id="calc1">
<h1>Calculator</h1>
<form id="calc">
<textarea id="d1" class="result" name="result" rows="1" cols="30"></textarea><br>
<button id="d2" class="numbers" type="button" onclick="fn(1)">1</button> 
<button id="d2" class="numbers" type="button" onclick="fn(2)">2</button>
<button id="d2" class="numbers" type="button" onclick="fn(3)">3</button> &nbsp; &nbsp; &nbsp;&nbsp;
<button id="d3" class="operator" type="button" onclick="fn('+')">+</button>
<button id="d3" class="operator" type="button" onclick="fn('-')">-</button><br>
<button id="d2" class="numbers" type="button" onclick="fn(4)">4</button> 
<button id="d2" class="numbers" type="button" onclick="fn(5)">5</button>
<button id="d2" class="numbers" type="button" onclick="fn(6)">6</button><br>
<button id="d2" class="numbers" type="button" onclick="fn(7)">7</button> 
<button id="d2" class="numbers" type="button" onclick="fn(8)">8</button>
<button id="d2" class="numbers" type="button" onclick="fn(9)">9</button><br> &nbsp; &nbsp; &nbsp;  &nbsp;&nbsp;
<button id="d2" class="numbers" type="button" onclick="fn(0)">0</button> &nbsp; &nbsp; &nbsp;&nbsp; &nbsp; &nbsp;  &nbsp;&nbsp; &nbsp;&nbsp;
<button id="clr" class="operator" type="button" onclick="update('')">CE</button><br><br>
<button class="complexity" type="button" onclick="adv()"><b>Advanced</b></button>&nbsp; &nbsp; &nbsp;&nbsp;&nbsp;
<button class="equal" type="button" onclick="main(document.getElementById('d1').value)">Equals</button>
</form>
</body>
</html>