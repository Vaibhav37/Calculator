function fn(x)
{
 
 	var y=document.getElementById("d1");
 	y.innerHTML=y.innerHTML+x;
 
}
function adv() {
    //$( "#calc" ).load( "calc_adv.php #calc" );
    var xhttp = new XMLHttpRequest();
  xhttp.onreadystatechange = function() {
    if (xhttp.readyState == 4 && xhttp.status == 200) {
      document.getElementById("calc1").innerHTML = xhttp.responseText;
    }
  };
  xhttp.open("GET", "calc_adv.php", true);
  xhttp.send();
}
function basic() {
    
    var xhttp = new XMLHttpRequest();
  xhttp.onreadystatechange = function() {
    if (xhttp.readyState == 4 && xhttp.status == 200) {
      document.getElementById("calc1").innerHTML = xhttp.responseText;
    }
  };
  xhttp.open("GET", "calc.php", true);
  xhttp.send();
}
function func(a)
{
var x=a[0];
var c=a[1];
var z=a[2];
var ans=0;
switch(c)
{
case '+':
ans=x+z;
break;
case '-':
ans=x-z;
break;
case '*':
ans=x*z;
break;
case '/':
ans=x/z;
break;
case '%':
ans=x%z;
break;
}
return ans;

}
function main(s)
{

	var st = [];
	var a=[];
	var num=0;var z=0;
	var res=0;var i=0;var j=0;
	var len=s.length;

	for(i=0;i<len;i++)
{

	if(s[i]>='0' && s[i]<='9')
	{
		st.push(s[i]);

		if(i==len-1)
        {
           while(st.length)
	      {
		     num+=Math.pow(10,j)*st.pop();
		     j++;
		     
          }
          a[z++]=num;

        }

	}
	else{

	while(st.length)
	{
		num+=Math.pow(10,j)*st.pop();

		j++;

		
	}
    
	j=0;

	a[z++]=num;
	a[z++]=s[i];
	num=0;}
	if(z>2)
	{
	    
		res=func(a);
        
		a[0]=res;
		a[1]=a[3];
		z=2;
		
	}
}

var output=document.getElementById('d1');

output.innerHTML=res;
}
function update(name){
    //document.getElementById('d1').value = name;
    window.location.reload();
}